﻿using UnityEngine;
using System.Collections;
namespace Designer.Runtime
{
    public class Node : MonoBehaviour
    {
        [Tooltip("name")]
        public string nodeName;
        public Node Front { get; set; }
        public Node Next { get; set; }
    }
}