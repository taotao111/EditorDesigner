﻿using UnityEngine;
using System.Collections;
using System;
namespace Designer.Runtime
{
    public class NodeTooltip : Attribute
    {
        private readonly string m_tooltip;
        public string Tooltip
        {
            get
            {
                return m_tooltip;
            }
        }
        public NodeTooltip(string tooltip)
        {
            m_tooltip = tooltip;
        }
    }
}