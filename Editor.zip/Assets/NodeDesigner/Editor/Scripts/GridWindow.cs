﻿using UnityEngine;
using System.Collections.Generic;
using UnityEditor;
using Designer.Runtime;
namespace Designer.Editor
{
    public enum MouseOperation
    {
        None,
        SelectionNode,
        MoveNode,
        MoveConnection,
    }
    public class GridWindow : EditorWindow
    {
        /// <summary>
        /// 线条材质球
        /// </summary>
        private Material mGridMaterial;
        /// <summary>
        /// 当前鼠标位置
        /// </summary>
        private Vector2 mCurrentMousePosition = Vector2.zero;
        /// <summary>
        /// 网格界面滚动位置
        /// </summary>
        private Vector2 mGraphScrollPosition = new Vector2(-1f, -1f);
        /// <summary>
        /// 格子区域比例
        /// </summary>
        private Vector2 mGraphOffset = Vector2.zero;
        /// <summary>
        /// 格子区域缩放比例
        /// </summary>
        private float mGraphZoom = 1f;
        /// <summary>
        /// 格子棋盘区域
        /// </summary>
        private Rect mGraphRect;
        /// <summary>
        /// 网格区域大小
        /// </summary>
        private Vector2 mGraphScrollSize = new Vector2(20000, 20000);

        private Rect mDragMouse = new Rect(0, 0, 0, 0);
        private MouseOperation mMouseStatus = MouseOperation.None;

        protected List<NodeData> selectionNodes = new List<NodeData>();
        protected NodeConnection selectionNodeConnection = null;
        protected List<NodeData> designerNodes
        {
            get
            {
                if (mNodeCollection == null)
                {
                    LoadCollection();
                }

                return mNodeCollection.collection;
            }
        }
        protected List<NodeConnection> designerConnection
        {
            get
            {
                if (mNodeCollection == null)
                {
                    LoadCollection();
                }
                return mNodeCollection.connection;
            }
        }
        private NodeDataCollection mNodeCollection;

        [MenuItem("Tools/GridWindow")]
        public static void Open()
        {
            EditorWindow.GetWindow<GridWindow>();
        }

        void OnEnable()
        {
            LoadCollection();

            //创建材质球用来渲染线条
            if (this.mGridMaterial == null)
            {
                this.mGridMaterial = new Material(Shader.Find("Hidden/Designer/Grid"));
                this.mGridMaterial.hideFlags = HideFlags.HideAndDontSave;
                this.mGridMaterial.shader.hideFlags = HideFlags.HideAndDontSave;
            }

            //窗口能否移动
            wantsMouseMove = true;

            SetNodeDirty();
        }
        void OnDisable()
        {
            SaveCollection();
            DestroyImmediate(mNodeCollection.gameObject);
        }
        void LoadCollection()
        {
            if (!System.IO.File.Exists(Application.dataPath + "/NodeDesigner/Editor/Prefabs/NodeCollection.prefab"))
            {
                GameObject go = new GameObject("NodeCollection");
                mNodeCollection = go.AddComponent<NodeDataCollection>();

                PrefabUtility.CreatePrefab("Assets/NodeDesigner/Editor/Prefabs/NodeCollection.prefab",go);
            }
            else
            {
                GameObject go = PrefabUtility.InstantiatePrefab(AssetDatabase.LoadAssetAtPath("Assets/NodeDesigner/Editor/Prefabs/NodeCollection.prefab", typeof(GameObject))) as GameObject;
                mNodeCollection = go.GetComponent<NodeDataCollection>();
                if (mNodeCollection == null)
                {
                    mNodeCollection = go.AddComponent<NodeDataCollection>();
                }
            }

            mGraphOffset = mNodeCollection.offset;
            if (mNodeCollection.scale <= 0.4f)
            {
                mNodeCollection.scale = 0.4f;
            }
            mGraphZoom = mNodeCollection.scale;
            mGraphScrollPosition = mNodeCollection.scrollPosition;
            mNodeCollection.Init();
        }
        void SaveCollection()
        {
            mNodeCollection.offset = mGraphOffset;
            mNodeCollection.scale = mGraphZoom;
            mNodeCollection.scrollPosition = mGraphScrollPosition;
            PrefabUtility.ReplacePrefab(mNodeCollection.gameObject, AssetDatabase.LoadAssetAtPath("Assets/NodeDesigner/Editor/Prefabs/NodeCollection.prefab", typeof(GameObject)));
        }
        void OnGUI()
        {
            //网格背景区域大小
            mGraphRect = new Rect(300, 21, position.width - 15 - 300, position.height - 21 - 15);

            //默认网格位于中心位置
            if (mGraphScrollPosition == new Vector2(-1, -1))
            {
                this.mGraphScrollPosition = (this.mGraphScrollSize - new Vector2(this.mGraphRect.width, this.mGraphRect.height)) / 2f - 2f * new Vector2(15f, 15f);
            }


            //刷新鼠标位置
            mCurrentMousePosition = Event.current.mousePosition;

            DrawGraphArea();
            HandleEvents();

        }
        protected void HandleEvents()
        {
            switch (Event.current.type)
            {
                case EventType.MouseDown:
                    {
                        if (Event.current.button == 0)
                        {
                            Vector2 mousePosition;
                            if (this.GetMousePositionInGraph(out mousePosition))
                            {
                                if (IsSelectConnection(mCurrentMousePosition))
                                {
                                    //
                                    Debug.LogError("Connection");
                                }

                                if (mMouseStatus == MouseOperation.None)
                                {
                                    //判断是否点击节点
                                    if (IsSelectNode(mCurrentMousePosition))
                                    {

                                    }
                                    else
                                    {
                                        mDragMouse.x = Screen2Scroll(mCurrentMousePosition).x;
                                        mDragMouse.y = Screen2Scroll(mCurrentMousePosition).y;
                                        mDragMouse.width = 1;
                                        mDragMouse.height = 1;

                                        mMouseStatus = MouseOperation.SelectionNode;
                                        SelectNode(mDragMouse);
                                    }
                                }


                            }

                            Event.current.Use();
                        }
                        else if (Event.current.button == 1)
                        {
                            if (selectionNodes.Count == 1)
                            {
                                AddRightButtonMenuSingle();
                            }
                            else if (selectionNodes.Count > 1)
                            {
                                AddRightButtonMenuMutil();
                            }
                            else
                            {
                                AddRightButtonMenuNull();
                            }
                            Event.current.Use();
                        }
                        break;
                    }
                case EventType.MouseUp:
                    {
                        if (Event.current.button == 0)
                        {
                            switch (mMouseStatus)
                            {
                                case MouseOperation.SelectionNode:
                                    {
                                        mDragMouse.x = 0;
                                        mDragMouse.y = 0;
                                        mDragMouse.width = 0;
                                        mDragMouse.height = 0;
                                        break;
                                    }
                                case MouseOperation.MoveNode:
                                    {
                                        mDragMouse.x = 0;
                                        mDragMouse.y = 0;
                                        mDragMouse.width = 0;
                                        mDragMouse.height = 0;
                                        break;
                                    }
                                case MouseOperation.MoveConnection:
                                    {
                                        selectionNodeConnection.selected = false;
                                        selectionNodeConnection.beginPoint.selected = false;
                                        selectionNodeConnection.endPoint.selected = false;
                                        selectionNodeConnection = null;
                                        break;
                                    }
                            }


                            mMouseStatus = MouseOperation.None;
                            Event.current.Use();
                        }
                        break;
                    }
                case EventType.MouseDrag:
                    {
                        if (Event.current.button == 2 && this.MousePan())
                        {
                            Event.current.Use();
                        }
                        else if (Event.current.button == 0)
                        {
                            switch (mMouseStatus)
                            {
                                case MouseOperation.MoveNode://移动节点
                                    {
                                        for (int i = 0; i < selectionNodes.Count; i++)
                                        {
                                            selectionNodes[i].UpdateRect(Event.current.delta);
                                            Event.current.Use();
                                        }
                                        break;
                                    }
                                case MouseOperation.SelectionNode://选择节点，描绘选择框
                                    {
                                        mDragMouse.width = Screen2Scroll(mCurrentMousePosition).x - mDragMouse.x;
                                        mDragMouse.height = Screen2Scroll(mCurrentMousePosition).y - mDragMouse.y;
                                        SelectNode(mDragMouse);
                                        Event.current.Use();
                                        break;
                                    }
                                case MouseOperation.MoveConnection:
                                    {
                                        if (selectionNodeConnection.beginPoint.selected)
                                        {
                                            selectionNodeConnection.beginPoint.Position = Screen2Scroll(mCurrentMousePosition);
                                        }
                                        else if (selectionNodeConnection.endPoint.selected)
                                        {
                                            selectionNodeConnection.endPoint.Position = Screen2Scroll(mCurrentMousePosition);
                                        }
                                        Event.current.Use();
                                        break;
                                    }
                            }
                            
                        }
                        break;
                    }
                case EventType.scrollWheel:
                    {
                        if (MouseZoom())
                        {
                            Event.current.Use();
                        }
                        break;
                    }
                case EventType.KeyDown:
                    {
                        if (Event.current.keyCode == KeyCode.Delete)
                        {
                            //if (mMouseStatus == MouseOperation.Move)
                            {
                                for (int i = selectionNodes.Count - 1; i >= 0; i--)
                                {
                                    mNodeCollection.Remove(selectionNodes[i]);
                                }
                                selectionNodes.Clear();
                            }
                            Event.current.Use();
                        }
                        break;
                    }

            }
        }
        #region 背景功能
        protected bool DrawGraphArea()
        {
            GUI.Box(this.mGraphRect, string.Empty, DesignerUtility.GraphBackgroundGUIStyle);
            this.DrawGrid();
            EditorZoomArea.Begin(this.mGraphRect, this.mGraphZoom);
            Vector2 mousePosition;
            if (!this.GetMousePositionInGraph(out mousePosition))
            {
                mousePosition = new Vector2(-1f, -1f);
            }
            
            EditorZoomArea.End();

            if (Event.current.type != EventType.ScrollWheel)
            {
                Vector2 vector = GUI.BeginScrollView(new Rect(this.mGraphRect.x, this.mGraphRect.y, this.mGraphRect.width + 15f, this.mGraphRect.height + 15f), this.mGraphScrollPosition, new Rect(0f, 0f, this.mGraphScrollSize.x, this.mGraphScrollSize.y), true, true);
                if (vector != this.mGraphScrollPosition && Event.current.type != EventType.DragUpdated && Event.current.type != EventType.Ignore)
                {
                    this.mGraphOffset -= (vector - this.mGraphScrollPosition) / this.mGraphZoom;
                    this.mGraphScrollPosition = vector;
                }

                DrawNode();

                if (mMouseStatus == MouseOperation.SelectionNode)
                {
                    NodeDesigner.DrawRect(mDragMouse, DesignerUtility.SelectionGUIStyle);
                }
                GUI.EndScrollView();
            }



            return true;
        }
        /// <summary>
        /// 画背景格子棋盘
        /// </summary>
        protected void DrawGrid()
        {
            this.mGridMaterial.SetPass((!EditorGUIUtility.isProSkin) ? 1 : 0);
            GL.PushMatrix();
            GL.Begin(1);
            this.DrawGridLines(10f * this.mGraphZoom, new Vector2(this.mGraphOffset.x % 10f * this.mGraphZoom, this.mGraphOffset.y % 10f * this.mGraphZoom));
            GL.End();
            GL.PopMatrix();
            this.mGridMaterial.SetPass((!EditorGUIUtility.isProSkin) ? 3 : 2);
            GL.PushMatrix();
            GL.Begin(1);
            this.DrawGridLines(50f * this.mGraphZoom, new Vector2(this.mGraphOffset.x % 50f * this.mGraphZoom, this.mGraphOffset.y % 50f * this.mGraphZoom));
            GL.End();
            GL.PopMatrix();
        }
        /// <summary>
        /// 画格子棋盘线条
        /// </summary>
        /// <param name="gridSize"></param>
        /// <param name="offset"></param>
        protected void DrawGridLines(float gridSize, Vector2 offset)
        {
            float num = this.mGraphRect.x + offset.x;
            if (offset.x < 0f)
            {
                num += gridSize;
            }
            for (float num2 = num; num2 < this.mGraphRect.x + this.mGraphRect.width; num2 += gridSize)
            {
                this.DrawLine(new Vector2(num2, this.mGraphRect.y), new Vector2(num2, this.mGraphRect.y + this.mGraphRect.height));
            }
            float num3 = this.mGraphRect.y + offset.y;
            if (offset.y < 0f)
            {
                num3 += gridSize;
            }
            for (float num4 = num3; num4 < this.mGraphRect.y + this.mGraphRect.height; num4 += gridSize)
            {
                this.DrawLine(new Vector2(this.mGraphRect.x, num4), new Vector2(this.mGraphRect.x + this.mGraphRect.width, num4));
            }
        }
        /// <summary>
        /// 画线
        /// </summary>
        /// <param name="p1"></param>
        /// <param name="p2"></param>
        protected void DrawLine(Vector2 p1, Vector2 p2)
        {
            GL.Vertex(p1);
            GL.Vertex(p2);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="mousePosition"></param>
        /// <returns></returns>
        protected bool GetMousePositionInGraph(out Vector2 mousePosition)
        {
            mousePosition = this.mCurrentMousePosition;
            if (!this.mGraphRect.Contains(mousePosition))
            {
                return false;
            }

            mousePosition -= new Vector2(this.mGraphRect.xMin, this.mGraphRect.yMin);
            mousePosition /= this.mGraphZoom;
            return true;
        }
        /// <summary>
        /// 控制界面的移动
        /// </summary>
        /// <returns></returns>
        protected bool MousePan()
        {
            Vector2 vector;
            if (!this.GetMousePositionInGraph(out vector))
            {
                return false;
            }
            Vector2 vector2 = Event.current.delta;
            if (Event.current.type == EventType.ScrollWheel)
            {
                vector2 *= -1.5f;
                if (Event.current.modifiers == EventModifiers.Control)
                {
                    vector2.x = vector2.y;
                    vector2.y = 0f;
                }
            }
            this.ScrollGraph(vector2);
            return true;
        }
        protected void ScrollGraph(Vector2 amount)
        {
            this.mGraphOffset += amount / this.mGraphZoom;
            this.mGraphScrollPosition -= amount;
            SetNodeDirty();
            base.Repaint();
        }
        /// <summary>
        /// 控制界面的缩放
        /// </summary>
        /// <returns></returns>
        protected bool MouseZoom()
        {
            Vector2 b;
            if (!this.GetMousePositionInGraph(out b))
            {
                return false;
            }
            float num = -Event.current.delta.y / 150f;
            float origin = mGraphZoom;
            this.mGraphZoom += num;
            this.mGraphZoom = Mathf.Clamp(this.mGraphZoom, 0.4f, 1.5f);
            Vector2 a;
            this.GetMousePositionInGraph(out a);
            this.mGraphOffset += a - b;
            //this.mGraphScrollPosition += a - b;
            //mGraphScrollPosition += a - b;
            //mGraphScrollPosition += a - b;
            SetNodeDirty();
            SetNodeDirty(origin);
            return true;
        }

        #endregion
        #region 描绘节点
        /// <summary>
        /// 描绘节点和连接线
        /// </summary>
        protected void DrawNode()
        {
            for (int i = 0; i < designerNodes.Count; i++)
            {
                NodeDesigner.DrawNode(designerNodes[i], true, true);
            }
            for (int i = 0; i < designerConnection.Count; i++)
            {
                NodeDesigner.DrawCurves(designerConnection[i], new Color(0.6f, 0.6f, 0.6f, 1));
            }
        }
        /// <summary>
        /// 刷新节点位置
        /// </summary>
        protected void SetNodeDirty()
        {
            for (int i = 0; i < designerNodes.Count; i++)
            {
                designerNodes[i].UpdateRect(mGraphZoom);
            }
            for (int i = 0; i < designerConnection.Count; i++)
            {
                designerConnection[i].UpdatePointPosition();
            }
        }
        /// <summary>
        /// 刷新节点位置
        /// </summary>
        /// <param name="origin"></param>
        protected void SetNodeDirty(float origin)
        {
            for (int i = 0; i < designerNodes.Count; i++)
            {
                designerNodes[i].Position = Screen2Scroll(mCurrentMousePosition) + (designerNodes[i].Position - Screen2Scroll(mCurrentMousePosition)) / origin * mGraphZoom;
            }
        }
        #endregion
        #region MOUSE BUTTON 0 FUNTION
        /// <summary>
        /// 选择节点
        /// </summary>
        /// <param name="rect"></param>
        public void SelectNode(Rect rect)
        {
            selectionNodes.Clear();
            for (int i = 0; i < designerNodes.Count; i++)
            {
                if (rect.Contains(designerNodes[i].Position))
                {
                    selectionNodes.Add(designerNodes[i]);
                    designerNodes[i].selected = true;
                }
                else
                {
                    designerNodes[i].selected = false;
                }
            }
            if (selectionNodes.Count > 0)
            {
                mMouseStatus = MouseOperation.SelectionNode;
            }
        }
        /// <summary>
        /// 判断鼠标位置是否再节点内
        /// </summary>
        /// <param name="mousePosition"></param>
        /// <returns></returns>
        public bool IsSelectNode(Vector2 mousePosition)
        {
            mousePosition = Screen2Scroll(mousePosition);
            for (int i = 0; i < designerNodes.Count; i++)
            {
                if (designerNodes[i].Rect.Contains(mousePosition))
                {
                    designerNodes[i].selected = true;
                    if (selectionNodes.Contains(designerNodes[i]))
                    {
                        mMouseStatus = MouseOperation.MoveNode;
                    }
                    else
                    {
                        foreach (var it in selectionNodes)
                        {
                            it.selected = false;
                        }
                        selectionNodes.Clear();
                        selectionNodes.Add(designerNodes[i]);
                        mMouseStatus = MouseOperation.MoveNode;
                    }
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 选择连接线
        /// </summary>
        /// <param name="mousePosition"></param>
        /// <returns></returns>
        public bool IsSelectConnection(Vector2 mousePosition)
        {
            mousePosition = Screen2Scroll(mousePosition);
            for (int i = 0; i < designerConnection.Count; i++)
            {
                if (designerConnection[i].beginPoint.Rect.Contains(mousePosition))
                {
                    selectionNodeConnection = designerConnection[i];
                    selectionNodeConnection.selected = true;
                    selectionNodeConnection.beginPoint.selected = true;
                    mMouseStatus = MouseOperation.MoveConnection;
                    return true;
                }

                if (designerConnection[i].endPoint.Rect.Contains(mousePosition))
                {
                    selectionNodeConnection = designerConnection[i];
                    selectionNodeConnection.selected = true;
                    selectionNodeConnection.endPoint.selected = true;
                    mMouseStatus = MouseOperation.MoveConnection;
                    return true;
                }
            }
            return false;
        }
        public NodePosition CalculateNodePosition(NodeConnection nodeCon)
        {

            return NodePosition.Bottom;
        }
        #endregion

        /// <summary>
        /// 转换当前鼠标位置到桂东条中的位置
        /// </summary>
        /// <param name="mousePosition"></param>
        /// <returns></returns>
        public Vector2 Screen2Scroll(Vector2 mousePosition)
        {
            return new Vector2(mCurrentMousePosition.x + mGraphScrollPosition.x - 300, mCurrentMousePosition.y + mGraphScrollPosition.y - 21);
        }

        #region MOUSE BUTTON 1 FUNTION
        private GenericMenu genericMenu = new GenericMenu();

        #region 选择单个Node时，鼠标右键功能
        public void AddRightButtonMenuSingle()
        {
            genericMenu = new GenericMenu();

            genericMenu.AddItem(new GUIContent("Add/Connection"), false, DeleteNode);
            genericMenu.AddSeparator("");

            genericMenu.AddItem(new GUIContent("Delete (Ctrl + Delete)"), false, DeleteNode);

            genericMenu.ShowAsContext();
        }
        /// <summary>
        /// 删除节点
        /// </summary>
        private void DeleteNode()
        {
            for (int i = selectionNodes.Count - 1; i >= 0; i--)
            {
                mNodeCollection.Remove(selectionNodes[i]);
            }
            selectionNodes.Clear();
        }
        #endregion
        #region 选择多个Node时，鼠标右键功能
        public void AddRightButtonMenuMutil()
        {
            genericMenu = new GenericMenu();

            genericMenu.AddSeparator("");

            genericMenu.AddItem(new GUIContent("Delete (Ctrl + Delete)"), false, DeleteNode);

            genericMenu.ShowAsContext();
        }
        #endregion
        #region 未选择Node时，鼠标右键功能
        public void AddRightButtonMenuNull()
        {
            genericMenu = new GenericMenu();

            genericMenu.AddItem(new GUIContent("Add Node/Node"), false, RBNullAddNode);
            genericMenu.AddSeparator("");

            genericMenu.ShowAsContext();
        }
        public void RBNullAddNode()
        {
            mNodeCollection.Add(new NodeData() { nodeColor = NodeColor.Purple, Position = Screen2Scroll(mCurrentMousePosition) });
            if (designerNodes.Count >= 2)
            {
                mNodeCollection.Add(new NodeConnection(designerNodes[designerNodes.Count - 1], designerNodes[designerNodes.Count - 2]));
            }
            SetNodeDirty();
        }
        #endregion
        #endregion
    }
}