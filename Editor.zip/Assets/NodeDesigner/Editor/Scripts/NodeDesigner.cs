﻿using UnityEngine;
using System.Collections;
using Designer.Runtime;
using UnityEditor;

namespace Designer.Editor
{
    public class NodeDesigner
    {
        public static void DrawNode(NodeData node,bool selected,bool enable)
        {
            foreach (var it in node.nodeCollection)
            {
                if (it.enable)
                {
                    GUI.Label(it.Rect, string.Empty, DesignerUtility.GetBackgroundGUIStyle(node.nodeColor));
                }
            }


            //Rect rectTop = new Rect(node.Position.x - 10, node.Position.y - node.Rect.height * 0.5f - 12.5f, 20, 25);
            //GUI.Label(rectTop, string.Empty, DesignerUtility.GetBackgroundGUIStyle(node.nodeColor));
            //DrawTexture(rectTop, DesignerUtility.GetTopTextures(node.nodeColor));
            //选中效果
            if (node.selected)
            {
                GUI.Label(new Rect(node.Rect.x - 1, node.Rect.y - 1, node.Rect.width + 2, node.Rect.height + 2), string.Empty, DesignerUtility.GetNodeSelectGUIStyle(node.nodeColor));
            }

            //背景框
            GUI.Label(node.Rect, string.Empty, DesignerUtility.GetBackgroundGUIStyle(node.nodeColor));


            DrawTexture(node.Rect,null);
        }

        public static void DrawTexture(Rect rect,Texture2D iconBorderTexture)
        {
            GUI.DrawTexture(rect, iconBorderTexture);
        }
        public static void DrawCurves(Rect wr, Rect wr2, Color color)
        {
            Vector3 startPos = new Vector3(wr.x + wr.width, wr.y + 3 + wr.height / 3, 0);
            Vector3 endPos = new Vector3(wr2.x, wr2.y + wr2.height / 2, 0);
            float mnog = Vector3.Distance(startPos, endPos);
            Vector3 startTangent = startPos + Vector3.right * (mnog / 3f);
            Vector3 endTangent = endPos + Vector3.left * (mnog / 3f);
            Handles.BeginGUI();
            Handles.DrawBezier(startPos, endPos, startTangent, endTangent, color, null, 5f);
            Handles.EndGUI();
        }
        public static void DrawCurves(NodeConnection connection, Color color)
        {
            Vector3 startPos = connection.beginPoint.Position;
            Vector3 endPos = connection.endPoint.Position;
            float mnog = Vector3.Distance(startPos, endPos);
            //Vector3 startTangent = startPos + Vector3.down * (mnog / 3f);
            //Vector3 endTangent = endPos + Vector3.up * (mnog / 3f);
            Vector3 startTangent = startPos;
            Vector3 endTangent = endPos;

            switch (connection.beginPoint.nodePosition)
            {
                case NodePosition.Top:
                    {
                        startTangent += Vector3.down * (mnog / 3f);
                        break;
                    }
                case NodePosition.Bottom:
                    {
                        startTangent += Vector3.up * (mnog / 3f);
                        break;
                    }
                case NodePosition.Left:
                    {
                        startTangent += Vector3.left * (mnog / 3f);
                        break;
                    }
                case NodePosition.Right:
                    {
                        startTangent += Vector3.right * (mnog / 3f);
                        break;
                    }
            }
            switch (connection.endPoint.nodePosition)
            {
                case NodePosition.Top:
                    {
                        endTangent += Vector3.down * (mnog / 3f);
                        break;
                    }
                case NodePosition.Bottom:
                    {
                        endTangent += Vector3.up * (mnog / 3f);
                        break;
                    }
                case NodePosition.Left:
                    {
                        endTangent += Vector3.left * (mnog / 3f);
                        break;
                    }
                case NodePosition.Right:
                    {
                        endTangent += Vector3.right * (mnog / 3f);
                        break;
                    }
            }
            Handles.BeginGUI();
            Handles.DrawBezier(startPos, endPos, startTangent, endTangent, color, null, 5f);
            Handles.EndGUI();
            //画点
            DrawTexture(connection.beginPoint.Rect, DesignerUtility.GetNodeConnectionTextures(connection.Begin.nodeColor));
            DrawTexture(connection.endPoint.Rect, DesignerUtility.GetNodeConnectionTextures(connection.End.nodeColor));
        }

        public static void DrawRect(Rect rect, GUIStyle guiStyle)
        {
            GUI.Label(rect, string.Empty, guiStyle);
        }
    }

}